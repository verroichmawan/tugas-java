/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package luaslingkaran;

/**
 *
 * @author USER
 */
public class Luaslingkaran {
    public static void main(String[]args){
        double jarijari = 6;
        double phi = 3.14;
        double luaslingkaran = phi*jarijari*jarijari;
        System.out.println("jarijari = "+jarijari);
        System.out.println("phi = "+phi);
        System.out.println("luas lingkaran adalah"+luaslingkaran);
      
        
    }

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
    }
    
}
